package com.anis.unss;

import android.app.Activity;
import android.app.NotificationManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AdhanFullScreenActivity extends Activity {
    private int notificationId;
    private final int gold = Color.rgb(239, 207, 132);
    private final int pale = Color.rgb(222, 237, 255);

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.rgb(5, 18, 54));
        getWindow().setNavigationBarColor(Color.rgb(5, 18, 54));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        notificationId = getIntent().getIntExtra("notificationId", 0);
        String prayer = getIntent().getStringExtra("prayer");
        if (prayer == null || prayer.trim().isEmpty()) prayer = "الصلاة";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(26), dp(24), dp(26), dp(24));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(5, 18, 54), Color.rgb(15, 61, 135), Color.rgb(5, 23, 67)});
        root.setBackground(bg);

        TextView brand = new TextView(this);
        brand.setText("أُنْس  |  UNSS");
        brand.setTextColor(gold); brand.setTextSize(23);
        brand.setTypeface(Typeface.create("serif", Typeface.BOLD));
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(-1, -2);
        brandLp.topMargin = dp(12); brandLp.bottomMargin = dp(20);
        root.addView(brand, brandLp);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable logoFrame = new GradientDrawable();
        logoFrame.setShape(GradientDrawable.OVAL); logoFrame.setColor(Color.WHITE);
        logoFrame.setStroke(dp(2), gold);
        logo.setBackground(logoFrame); logo.setPadding(dp(10), dp(10), dp(10), dp(10));
        logo.setElevation(dp(8));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(118), dp(118));
        logoLp.bottomMargin = dp(28); root.addView(logo, logoLp);

        TextView title = new TextView(this);
        title.setText("حان موعد صلاة " + prayer);
        title.setTextColor(Color.WHITE); title.setTextSize(30);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setGravity(Gravity.CENTER); title.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("حيَّ على الصلاة"); sub.setTextColor(pale); sub.setTextSize(23);
        sub.setTypeface(Typeface.create("serif", Typeface.NORMAL)); sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(12); subLp.bottomMargin = dp(24); root.addView(sub, subLp);

        LinearLayout divider = new LinearLayout(this);
        GradientDrawable line = new GradientDrawable(); line.setColor(gold); line.setCornerRadius(dp(2));
        divider.setBackground(line);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(dp(74), dp(3));
        lineLp.bottomMargin = dp(20); root.addView(divider, lineLp);

        TextView reminder = new TextView(this);
        reminder.setText("استعد للصلاة، جعلها الله راحةً لقلبك");
        reminder.setTextColor(pale); reminder.setTextSize(17);
        reminder.setGravity(Gravity.CENTER); reminder.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(reminder, new LinearLayout.LayoutParams(-1, -2));

        View spacer = new View(this); root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));

        Button close = new Button(this);
        close.setText("إغلاق واجهة الأذان"); close.setTextColor(Color.rgb(5, 28, 76));
        close.setTextSize(17); close.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        close.setAllCaps(false); close.setPadding(dp(18), dp(8), dp(18), dp(8));
        GradientDrawable buttonBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{gold, Color.rgb(255, 239, 195)});
        buttonBg.setCornerRadius(dp(28)); buttonBg.setStroke(dp(1), Color.WHITE);
        close.setBackground(buttonBg); close.setElevation(dp(6));
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(-1, dp(58));
        closeLp.bottomMargin = dp(12); root.addView(close, closeLp);
        close.setOnClickListener(v -> closeScreen());

        setContentView(root);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void closeScreen() {
        try { if (notificationId != 0) ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(notificationId); } catch (Exception ignored) {}
        finish();
    }
    @Override public void onBackPressed() { closeScreen(); }
}
