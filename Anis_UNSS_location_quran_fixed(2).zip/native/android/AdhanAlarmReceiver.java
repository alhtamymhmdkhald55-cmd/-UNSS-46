package com.anis.unss;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AdhanAlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "anis-adhan-channel-v3";
    @Override public void onReceive(Context context, Intent intent) {
        String prayer = intent.getStringExtra("prayer");
        if (prayer == null || prayer.trim().isEmpty()) prayer = "الصلاة";
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "واجهة الأذان - أُنْس", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("عرض شاشة الأذان عند دخول وقت الصلاة");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.setBypassDnd(false);
            Uri adhanSound = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.adhan);
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            channel.setSound(adhanSound, audioAttributes);
            channel.enableVibration(true);
            nm.createNotificationChannel(channel);
        }
        int id = (int)(System.currentTimeMillis() & 0x7fffffff);
        Intent show = new Intent(context, AdhanFullScreenActivity.class);
        show.putExtra("prayer", prayer);
        show.putExtra("notificationId", id);
        show.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent full = PendingIntent.getActivity(context, id, show, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, CHANNEL) : new Notification.Builder(context);
        b.setSmallIcon(R.drawable.ic_stat_anis)
         .setContentTitle("أُنْس | حان موعد صلاة " + prayer)
         .setContentText("حان الآن موعد الأذان")
         .setCategory(Notification.CATEGORY_ALARM)
         .setPriority(Notification.PRIORITY_MAX)
         .setVisibility(Notification.VISIBILITY_PUBLIC)
         .setAutoCancel(true)
         .setContentIntent(full)
         .setFullScreenIntent(full, true);
        nm.notify(id, b.build());
    }
}
